
"""Simple Loan EMI Explorer - robust local finance application.
Python 3.10+. Matplotlib is optional and used only for charts.
"""
from __future__ import annotations

import csv
import json
import math
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

APP_NAME = "SIMPLE LOAN EMI EXPLORER"
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "loan_data"
REPORT_DIR = BASE_DIR / "reports"
JSON_FILE = DATA_DIR / "loan_records.json"
CSV_FILE = DATA_DIR / "loan_records.csv"
AUDIT_FILE = DATA_DIR / "activity_log.txt"
IMPORT_ERRORS_FILE = REPORT_DIR / "import_errors.txt"

CATEGORIES = ("Education", "Home", "Personal", "Vehicle", "Business", "Other")

CSV_FIELDS = [
    "loan_id", "customer_name", "category", "principal",
    "annual_rate", "tenure_months", "monthly_emi",
    "total_payment", "total_interest", "created_at"
]

MAX_PRINCIPAL = 1_000_000_000.0
MAX_RATE = 100.0
MAX_MONTHS = 600


@dataclass
class LoanRecord:
    loan_id: str
    customer_name: str
    category: str
    principal: float
    annual_rate: float
    tenure_months: int
    monthly_emi: float
    total_payment: float
    total_interest: float
    created_at: str

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def now_text() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def money(value: float) -> str:
    return f"Rs. {value:,.2f}"


def heading(title: str) -> None:
    print("\n" + "=" * 76)
    print(title.center(76))
    print("=" * 76)


def pause() -> None:
    input("\nPress Enter to return to the main menu...")


def audit(message: str) -> None:
    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        with AUDIT_FILE.open("a", encoding="utf-8") as file:
            file.write(f"[{now_text()}] {message}\n")
    except OSError as error:
        print(f"Warning: Activity log could not be updated: {error}")


# ---------------- EMI CALCULATION ENGINE ----------------

def calculate_emi(
    principal: float,
    annual_rate: float,
    months: int
) -> tuple[float, float, float]:

    if not all(math.isfinite(x) for x in (principal, annual_rate)):
        raise ValueError("Loan values must be finite numbers.")

    if (
        principal <= 0
        or not (0 <= annual_rate <= MAX_RATE)
        or not (1 <= months <= MAX_MONTHS)
    ):
        raise ValueError("Loan values are outside the permitted range.")

    monthly_rate = annual_rate / 1200.0

    if monthly_rate == 0:
        emi = principal / months
    else:
        factor = (1.0 + monthly_rate) ** months
        emi = (
            principal * monthly_rate * factor
            / (factor - 1.0)
        )

    total = emi * months
    interest = total - principal

    return round(emi, 2), round(total, 2), round(interest, 2)


# ---------------- INPUT VALIDATION ----------------

def get_text(prompt: str, max_length: int = 80) -> str:

    while True:
        value = input(prompt).strip()

        if not value:
            print("This field cannot be blank.")

        elif len(value) > max_length:
            print(f"Enter no more than {max_length} characters.")

        elif any(ord(ch) < 32 for ch in value):
            print("Control characters are not allowed.")

        else:
            return value


def get_number(
    prompt: str,
    minimum: float,
    maximum: float
) -> float:

    while True:
        raw = input(prompt).strip().replace(",", "")

        try:
            value = float(raw)

            if not math.isfinite(value):
                raise ValueError

            if minimum <= value <= maximum:
                return value

            print(f"Enter a value from {minimum:g} to {maximum:g}.")

        except ValueError:
            print("Invalid input. Enter a valid number.")


def get_integer(
    prompt: str,
    minimum: int,
    maximum: int
) -> int:

    while True:
        raw = input(prompt).strip()

        try:
            value = int(raw)

            if minimum <= value <= maximum:
                return value

            print(f"Enter a whole number from {minimum} to {maximum}.")

        except ValueError:
            print("Invalid input. Enter a whole number.")


def choose_category() -> str:

    print("\nLOAN CATEGORIES")

    for index, category in enumerate(CATEGORIES, 1):
        print(f"{index}. {category}")

    choice = get_integer(
        "Choose category: ",
        1,
        len(CATEGORIES)
    )

    return CATEGORIES[choice - 1]


# ---------------- RECORD VALIDATION ----------------

def validate_record(raw: dict[str, Any]) -> LoanRecord:

    name = str(raw.get("customer_name", "")).strip()
    category = str(raw.get("category", "")).strip().title()

    if not name or len(name) > 80:
        raise ValueError("Customer name is blank or too long.")

    if category not in CATEGORIES:
        raise ValueError("Invalid loan category.")

    principal = float(raw["principal"])
    rate = float(raw["annual_rate"])
    months = int(raw["tenure_months"])

    if not math.isfinite(principal):
        raise ValueError("Invalid principal amount.")

    if not (0 < principal <= MAX_PRINCIPAL):
        raise ValueError("Principal amount is outside the permitted range.")

    if not math.isfinite(rate) or not (0 <= rate <= MAX_RATE):
        raise ValueError("Invalid annual interest rate.")

    if not (1 <= months <= MAX_MONTHS):
        raise ValueError("Invalid loan tenure.")

    emi, total, interest = calculate_emi(
        principal,
        rate,
        months
    )

    loan_id = str(
        raw.get("loan_id") or
        f"LN-{uuid.uuid4().hex[:10].upper()}"
    ).strip()

    created = str(raw.get("created_at") or now_text()).strip()

    return LoanRecord(
        loan_id,
        name,
        category,
        principal,
        rate,
        months,
        emi,
        total,
        interest,
        created
    )


# ---------------- FILE STORAGE ----------------

def atomic_write_text(path: Path, content: str) -> None:

    path.parent.mkdir(parents=True, exist_ok=True)

    temp = path.with_suffix(path.suffix + ".tmp")

    temp.write_text(content, encoding="utf-8")
    temp.replace(path)


def save_records(records: list[LoanRecord]) -> bool:

    try:
        DATA_DIR.mkdir(parents=True, exist_ok=True)

        json_text = json.dumps(
            [record.to_dict() for record in records],
            indent=4,
            ensure_ascii=False
        )

        atomic_write_text(JSON_FILE, json_text)

        temp = CSV_FILE.with_suffix(".csv.tmp")

        with temp.open(
            "w",
            newline="",
            encoding="utf-8-sig"
        ) as file:

            writer = csv.DictWriter(
                file,
                fieldnames=CSV_FIELDS
            )

            writer.writeheader()

            writer.writerows(
                record.to_dict() for record in records
            )

        temp.replace(CSV_FILE)

        return True

    except (OSError, TypeError, ValueError) as error:
        print(f"Storage error: {error}")
        return False


def load_json_records() -> list[LoanRecord]:

    with JSON_FILE.open("r", encoding="utf-8") as file:
        data = json.load(file)

    if not isinstance(data, list):
        raise ValueError("JSON root must be a list.")

    records = []

    for item in data:

        if not isinstance(item, dict):
            continue

        try:
            records.append(validate_record(item))

        except (ValueError, TypeError, KeyError, OverflowError):
            continue

    return records


def load_csv_records() -> list[LoanRecord]:

    with CSV_FILE.open(
        "r",
        newline="",
        encoding="utf-8-sig"
    ) as file:

        reader = csv.DictReader(file)

        if (
            not reader.fieldnames
            or not set(CSV_FIELDS).issubset(reader.fieldnames)
        ):
            raise ValueError("CSV backup has missing columns.")

        records = []

        for row in reader:

            try:
                records.append(validate_record(row))

            except (ValueError, TypeError, KeyError, OverflowError):
                continue

        return records


def load_records() -> list[LoanRecord]:

    DATA_DIR.mkdir(parents=True, exist_ok=True)

    if JSON_FILE.exists():

        try:
            records = load_json_records()
            print(f"Loaded {len(records)} records from JSON.")
            return records

        except (OSError, json.JSONDecodeError, ValueError) as error:
            print(f"JSON storage issue: {error}")
            print("Trying CSV recovery...")

    if CSV_FILE.exists():

        try:
            records = load_csv_records()
            print(f"Recovered {len(records)} records from CSV.")
            return records

        except (OSError, csv.Error, ValueError) as error:
            print(f"CSV recovery issue: {error}")

    print("Starting with an empty loan database.")

    return []


# ---------------- ADD NEW LOAN ----------------

def add_loan(records: list[LoanRecord]) -> None:

    heading("CREATE A NEW LOAN ESTIMATE")

    name = get_text("Customer name: ")

    category = choose_category()

    principal = get_number(
        "Loan amount (Rs.): ",
        0.01,
        MAX_PRINCIPAL
    )

    rate = get_number(
        "Annual interest rate (%): ",
        0,
        MAX_RATE
    )

    months = get_integer(
        "Tenure in months (1-600): ",
        1,
        MAX_MONTHS
    )

    record = validate_record({
        "customer_name": name,
        "category": category,
        "principal": principal,
        "annual_rate": rate,
        "tenure_months": months
    })

    heading("LOAN EMI CALCULATION RESULT")

    print(f"Loan ID              : {record.loan_id}")
    print(f"Customer             : {record.customer_name}")
    print(f"Category             : {record.category}")
    print(f"Loan amount          : {money(record.principal)}")
    print(f"Annual interest      : {record.annual_rate:.2f}%")
    print(f"Tenure               : {record.tenure_months} months")
    print(f"Monthly EMI           : {money(record.monthly_emi)}")
    print(f"Total interest        : {money(record.total_interest)}")
    print(f"Total repayment       : {money(record.total_payment)}")

    if record.annual_rate >= 15:
        print("WARNING: Interest rate is relatively high.")

    if record.principal >= 10_000_000:
        print("WARNING: High-value loan. Verify the amount.")

    answer = input("\nSave this loan record? (y/n): ").strip().lower()

    if answer == "y":

        records.append(record)

        if save_records(records):
            audit(
                f"Created loan {record.loan_id} "
                f"for {record.customer_name}"
            )

            print("Record saved successfully.")

        else:
            records.pop()
            print("Record was not saved because storage failed.")

    else:
        print("Estimate displayed but not saved.")


# ---------------- VIEW LOAN RECORDS ----------------

def display_records(
    records: list[LoanRecord],
    page_size: int = 10
) -> None:

    if not records:
        print("No loan records are available.")
        return

    total_pages = (
        len(records) + page_size - 1
    ) // page_size

    page = 0

    while True:

        start = page * page_size
        subset = records[start:start + page_size]

        heading(
            f"LOAN RECORDS - PAGE {page + 1}/{total_pages}"
        )

        print(
            f"{'ID':<16} {'CUSTOMER':<17} "
            f"{'CATEGORY':<12} {'PRINCIPAL':>13} {'EMI':>12}"
        )

        print("-" * 76)

        for record in subset:

            print(
                f"{record.loan_id[:15]:<16} "
                f"{record.customer_name[:16]:<17} "
                f"{record.category[:11]:<12} "
                f"{record.principal:>13,.0f} "
                f"{record.monthly_emi:>12,.2f}"
            )

        print(
            f"\nShowing {start + 1}-"
            f"{start + len(subset)} of {len(records)} records."
        )

        if total_pages == 1:
            break

        command = input(
            "N=next, P=previous, Q=quit: "
        ).strip().lower()

        if command == "n" and page < total_pages - 1:
            page += 1

        elif command == "p" and page > 0:
            page -= 1

        elif command == "q":
            break

        else:
            print("Choose N, P or Q.")


# ---------------- SEARCH AND FILTER ----------------

def search_records(records: list[LoanRecord]) -> None:

    heading("SEARCH AND FILTER LOAN RECORDS")

    if not records:
        print("No saved records to search.")
        return

    print("1. Search by customer name or loan ID")
    print("2. Filter by loan category")
    print("3. Filter by minimum loan amount")

    choice = input("Choose search method (1-3): ").strip()

    if choice == "1":

        term = get_text("Enter name or loan ID: ").casefold()

        matches = [
            record for record in records
            if (
                term in record.customer_name.casefold()
                or term in record.loan_id.casefold()
            )
        ]

    elif choice == "2":

        category = choose_category()

        matches = [
            record for record in records
            if record.category == category
        ]

    elif choice == "3":

        minimum = get_number(
            "Minimum loan amount (Rs.): ",
            0,
            MAX_PRINCIPAL
        )

        matches = [
            record for record in records
            if record.principal >= minimum
        ]

    else:
        print("Invalid search option.")
        return

    print(f"\nFound {len(matches)} matching records.")

    display_records(matches)


# ---------------- FINANCIAL SUMMARY ----------------

def show_summary(records: list[LoanRecord]) -> None:

    heading("EXECUTIVE FINANCIAL SUMMARY")

    if not records:
        print("No records available. Add or import records first.")
        return

    count = len(records)

    principal = sum(r.principal for r in records)
    interest = sum(r.total_interest for r in records)
    repayment = sum(r.total_payment for r in records)

    average_principal = principal / count

    average_emi = (
        sum(r.monthly_emi for r in records) / count
    )

    average_rate = (
        sum(r.annual_rate for r in records) / count
    )

    highest = max(records, key=lambda r: r.principal)
    lowest = min(records, key=lambda r: r.principal)

    print(f"Number of loan records       : {count}")
    print(f"Combined loan principal      : {money(principal)}")
    print(f"Combined estimated interest  : {money(interest)}")
    print(f"Combined repayment amount    : {money(repayment)}")
    print(f"Average loan amount          : {money(average_principal)}")
    print(f"Average monthly EMI          : {money(average_emi)}")
    print(f"Average annual interest      : {average_rate:.2f}%")

    print(
        f"Highest principal            : "
        f"{highest.customer_name} - {money(highest.principal)}"
    )

    print(
        f"Lowest principal             : "
        f"{lowest.customer_name} - {money(lowest.principal)}"
    )

    print("\nCATEGORY ANALYSIS")

    print(
        f"{'CATEGORY':<16} {'RECORDS':>9} "
        f"{'PRINCIPAL TOTAL':>22}"
    )

    print("-" * 50)

    for category in CATEGORIES:

        group = [
            r for r in records
            if r.category == category
        ]

        if group:

            print(
                f"{category:<16} "
                f"{len(group):>9} "
                f"{sum(r.principal for r in group):>22,.2f}"
            )

    high_rate = [
        r for r in records
        if r.annual_rate >= 15
    ]

    high_amount = [
        r for r in records
        if r.principal >= 10_000_000
    ]

    print("\nSTATUS INDICATORS")

    print(
        f"High-rate records (15% or above): "
        f"{len(high_rate)}"
    )

    print(
        f"High-value records (Rs. 1 crore or above): "
        f"{len(high_amount)}"
    )

    print(
        "Note: These are review flags, not overdue-payment "
        "or credit-risk assessments."
    )

    print("\nRECENT RECORD TREND")

    for record in records[-5:]:

        print(
            f"{record.created_at:<19} "
            f"{record.customer_name[:18]:<19} "
            f"{money(record.principal):>18}"
        )


# ---------------- MATPLOTLIB CHARTS ----------------

def generate_charts(records: list[LoanRecord]) -> None:

    heading("MATPLOTLIB DATA VISUALIZATION")

    if not records:
        print("No records available for plotting.")
        return

    try:
        import matplotlib.pyplot as plt

    except ImportError:
        print("Matplotlib is not installed for this Python interpreter.")
        print("Run: py -m pip install matplotlib")
        return

    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    labels = [
        f"{r.customer_name[:10]}-{i+1}"
        for i, r in enumerate(records)
    ]

    amounts = [r.principal for r in records]
    emis = [r.monthly_emi for r in records]

    category_counts = {
        category: sum(
            1 for r in records
            if r.category == category
        )
        for category in CATEGORIES
    }

    category_counts = {
        key: value
        for key, value in category_counts.items()
        if value
    }

    fig, axes = plt.subplots(2, 2, figsize=(14, 9))

    axes[0, 0].bar(labels, amounts)
    axes[0, 0].set_title("Loan Principal by Record")
    axes[0, 0].set_ylabel("Principal (Rs.)")
    axes[0, 0].tick_params(
        axis="x",
        rotation=70,
        labelsize=7
    )

    axes[0, 1].bar(labels, emis)
    axes[0, 1].set_title("Estimated Monthly EMI")
    axes[0, 1].set_ylabel("EMI (Rs.)")
    axes[0, 1].tick_params(
        axis="x",
        rotation=70,
        labelsize=7
    )

    axes[1, 0].pie(
        category_counts.values(),
        labels=category_counts.keys(),
        autopct="%1.1f%%"
    )

    axes[1, 0].set_title("Loan Category Distribution")

    axes[1, 1].plot(
        range(1, len(amounts) + 1),
        amounts,
        marker="o"
    )

    axes[1, 1].set_title("Principal Trend by Record Entry")
    axes[1, 1].set_xlabel("Record sequence")
    axes[1, 1].set_ylabel("Principal (Rs.)")
    axes[1, 1].grid(True, alpha=0.3)

    fig.suptitle(
        "Simple Loan EMI Explorer - Financial Analytics"
    )

    fig.tight_layout()

    chart_path = REPORT_DIR / "loan_analytics_dashboard.png"

    fig.savefig(
        chart_path,
        dpi=180,
        bbox_inches="tight"
    )

    plt.close(fig)

    print(f"Four visualizations saved to: {chart_path}")

    audit("Generated Matplotlib analytics dashboard")


# ---------------- REPORT EXPORT ----------------

def export_reports(records: list[LoanRecord]) -> None:

    heading("EXPORT FINANCIAL REPORTS")

    if not records:
        print("No records available to export.")
        return

    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    txt_path = REPORT_DIR / f"financial_report_{stamp}.txt"
    md_path = REPORT_DIR / f"financial_report_{stamp}.md"
    csv_path = REPORT_DIR / f"financial_report_{stamp}.csv"

    total_principal = sum(r.principal for r in records)
    total_interest = sum(r.total_interest for r in records)
    total_payment = sum(r.total_payment for r in records)

    lines = [
        APP_NAME,
        "=" * 60,
        f"Generated: {now_text()}",
        f"Number of records: {len(records)}",
        f"Total principal: {money(total_principal)}",
        f"Total estimated interest: {money(total_interest)}",
        f"Total repayment: {money(total_payment)}",
        "",
        "LOAN DETAILS",
        "-" * 60
    ]

    for index, record in enumerate(records, 1):

        lines.extend([
            f"{index}. {record.customer_name} | "
            f"{record.loan_id} | {record.category}",

            f"   Principal: {money(record.principal)} | "
            f"Rate: {record.annual_rate:.2f}% | "
            f"Tenure: {record.tenure_months} months",

            f"   Monthly EMI: {money(record.monthly_emi)} | "
            f"Total interest: {money(record.total_interest)}",

            ""
        ])

    try:

        atomic_write_text(
            txt_path,
            "\n".join(lines)
        )

        atomic_write_text(
            md_path,
            "# " + "\n\n".join(lines)
        )

        with csv_path.open(
            "w",
            newline="",
            encoding="utf-8-sig"
        ) as file:

            writer = csv.DictWriter(
                file,
                fieldnames=CSV_FIELDS
            )

            writer.writeheader()

            writer.writerows(
                record.to_dict() for record in records
            )

        print("\nReports created successfully:")

        print(f"Text report     : {txt_path}")
        print(f"Markdown report : {md_path}")
        print(f"CSV report      : {csv_path}")

        audit("Exported financial reports")

    except OSError as error:
        print(f"Report export failed: {error}")


# ---------------- BULK CSV IMPORT ----------------

def import_csv(records: list[LoanRecord]) -> None:

    heading("BULK CSV DATASET IMPORT")

    path = Path(
        get_text("Enter CSV file path: ", 250).strip('"')
    ).expanduser()

    if not path.is_file():
        print("File not found. Check the path.")
        return

    required = {
        "customer_name",
        "category",
        "principal",
        "annual_rate",
        "tenure_months"
    }

    accepted = []
    errors = []

    try:

        with path.open(
            "r",
            newline="",
            encoding="utf-8-sig"
        ) as file:

            reader = csv.DictReader(file)

            if (
                not reader.fieldnames
                or not required.issubset(set(reader.fieldnames))
            ):

                print("CSV is missing required columns.")
                print(
                    "Required: customer_name, category, principal, "
                    "annual_rate, tenure_months"
                )
                return

            for row_number, row in enumerate(reader, start=2):

                try:
                    accepted.append(validate_record(row))

                except (
                    ValueError,
                    TypeError,
                    KeyError,
                    OverflowError
                ) as error:

                    errors.append(
                        f"Row {row_number}: {error}"
                    )

    except (OSError, csv.Error) as error:
        print(f"CSV import failed: {error}")
        return

    existing_ids = {
        record.loan_id for record in records
    }

    unique = []

    for record in accepted:

        if record.loan_id in existing_ids:

            record.loan_id = (
                f"LN-{uuid.uuid4().hex[:10].upper()}"
            )

        existing_ids.add(record.loan_id)
        unique.append(record)

    combined = records + unique

    if unique and not save_records(combined):
        print("Import cancelled because saving failed.")
        return

    records.extend(unique)

    REPORT_DIR.mkdir(parents=True, exist_ok=True)

    try:

        atomic_write_text(
            IMPORT_ERRORS_FILE,
            "\n".join(errors)
            if errors
            else "All rows passed validation."
        )

    except OSError as error:
        print(f"Could not save import error log: {error}")

    print(f"Rows imported successfully: {len(unique)}")
    print(f"Rows rejected: {len(errors)}")
    print(f"Import error log: {IMPORT_ERRORS_FILE}")

    audit(
        f"CSV import completed: {len(unique)} accepted, "
        f"{len(errors)} rejected"
    )


# ---------------- SAMPLE DATA GENERATOR ----------------

def create_demo_dataset(records: list[LoanRecord]) -> None:

    heading("CREATE SAMPLE DEMONSTRATION DATA")

    if records:

        answer = input(
            "Existing records found. Add 30 demo records? (y/n): "
        ).strip().lower()

        if answer != "y":
            print("Demo data creation cancelled.")
            return

    names = [
        "Aarav Sharma", "Diya Reddy", "Kabir Rao",
        "Ananya Patel", "Ishaan Kumar", "Meera Nair",
        "Vivaan Singh", "Sara Khan", "Arjun Das",
        "Ira Verma", "Rohan Gupta", "Aadhya Joshi",
        "Dev Malhotra", "Myra Iyer", "Reyansh Shah",
        "Kiara Bose", "Advik Menon", "Saanvi Roy",
        "Yash Mehta", "Tara Pillai", "Neil Kapoor",
        "Riya Sethi", "Ayaan Jain", "Navya Kulkarni",
        "Om Prasad", "Mira Thomas", "Krish Bhat",
        "Anvi Rao", "Rudra Sen", "Zoya Ali"
    ]

    amounts = [
        50000, 85000, 120000, 175000, 220000,
        300000, 450000, 600000, 750000, 900000,
        1100000, 1300000, 1500000, 1800000, 2000000,
        2500000, 3000000, 3500000, 4000000, 4500000,
        5000000, 5500000, 6000000, 6500000, 7000000,
        7500000, 8000000, 9000000, 10000000, 12000000
    ]

    rates = [
        0, 6.5, 7, 7.5, 8, 8.25, 8.5, 9, 9.25, 9.5,
        10, 10.5, 11, 11.5, 12, 12.5, 13, 13.5,
        14, 14.5, 15, 8.75, 9.75, 10.25, 11.25,
        12.25, 13.25, 14.25, 15.5, 16
    ]

    categories = list(CATEGORIES)

    demo = []

    for index, name in enumerate(names):

        demo.append(
            validate_record({
                "customer_name": f"DEMO - {name}",
                "category": categories[index % len(categories)],
                "principal": amounts[index],
                "annual_rate": rates[index],
                "tenure_months": [
                    12, 18, 24, 36, 48, 60, 84, 120
                ][index % 8]
            })
        )

    if save_records(records + demo):

        records.extend(demo)

        print("30 demonstration records added successfully.")
        print("They are clearly labelled as DEMO records.")

        audit("Added 30 sample demonstration records")

    else:
        print("Demo records were not saved.")


# ---------------- ACTIVITY LOG ----------------

def view_activity_log() -> None:

    heading("ACTIVITY LOG")

    if not AUDIT_FILE.exists():
        print("No activity has been recorded yet.")
        return

    try:

        content = AUDIT_FILE.read_text(
            encoding="utf-8"
        ).strip()

        print(
            content if content
            else "Activity log is empty."
        )

    except OSError as error:
        print(f"Could not read activity log: {error}")


# ---------------- EMI SELF TEST ----------------

def self_test() -> None:

    heading("EMI CALCULATION SELF-TEST")

    cases = [
        (120000, 0, 12),
        (100000, 12, 12),
        (500000, 8.5, 60)
    ]

    passed = 0

    for principal, rate, months in cases:

        emi, total, interest = calculate_emi(
            principal,
            rate,
            months
        )

        valid = (
            emi > 0
            and total >= principal
            and math.isclose(
                total - principal,
                interest,
                abs_tol=0.02
            )
        )

        print(
            f"Principal={principal:,.2f}, "
            f"Rate={rate:.2f}%, Months={months}: "
            f"{'PASS' if valid else 'FAIL'}"
        )

        passed += int(valid)

    print(f"\nSelf-test result: {passed}/{len(cases)} passed.")


# ---------------- MAIN APPLICATION ----------------

def main() -> None:

    records = load_records()

    heading(APP_NAME)

    print(
        "A local application to estimate, store, "
        "search and analyse loan payments."
    )

    print(
        "All calculations are estimates and exclude "
        "lender fees or changing rates."
    )

    while True:

        heading("MAIN MENU")

        menu = [
            "Create a new loan estimate",
            "View all saved records",
            "Search and filter records",
            "Executive financial summary",
            "Generate Matplotlib charts",
            "Export financial reports",
            "Import records from CSV",
            "Create 30 sample demo records",
            "View activity log",
            "Run EMI calculation self-test",
            "Exit"
        ]

        for index, item in enumerate(menu, 1):
            print(f"{index:>2}. {item}")

        choice = input(
            "\nSelect an option (1-11): "
        ).strip()

        actions = {
            "1": lambda: add_loan(records),
            "2": lambda: display_records(records),
            "3": lambda: search_records(records),
            "4": lambda: show_summary(records),
            "5": lambda: generate_charts(records),
            "6": lambda: export_reports(records),
            "7": lambda: import_csv(records),
            "8": lambda: create_demo_dataset(records),
            "9": view_activity_log,
            "10": self_test
        }

        if choice in actions:

            try:
                actions[choice]()

            except (KeyboardInterrupt, EOFError):
                print("\nAction cancelled.")

            except Exception as error:
                print(f"Unexpected error: {error}")

                audit(
                    f"Unexpected error: "
                    f"{type(error).__name__}: {error}"
                )

            pause()

        elif choice == "11":

            if save_records(records):
                print("All records saved successfully.")

            print(
                "Thank you for using Simple Loan EMI Explorer."
            )

            break

        else:
            print("Invalid choice. Enter a number from 1 to 11.")


if __name__ == "__main__":

    try:
        main()

    except (KeyboardInterrupt, EOFError):
        print("\nApplication closed safely.")

