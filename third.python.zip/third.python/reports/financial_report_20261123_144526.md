# SIMPLE LOAN EMI EXPLORER

============================================================

Generated: 2026-11-23 14:45:26

Number of records: 4

Total principal: Rs. 39,050,000.00

Total estimated interest: Rs. 2,892,495.54

Total repayment: Rs. 41,942,495.54



LOAN DETAILS

------------------------------------------------------------

1. Hasini | LN-1A522F6DE3 | Education

   Principal: Rs. 30,000,000.00 | Rate: 10.00% | Tenure: 17 months

   Monthly EMI: Rs. 1,899,986.84 | Total interest: Rs. 2,299,776.25



2. Rajesh | LN-2759EA09CE | Home

   Principal: Rs. 7,000,000.00 | Rate: 10.00% | Tenure: 14 months

   Monthly EMI: Rs. 531,811.77 | Total interest: Rs. 445,364.80



3. Samyu | LN-4B23107C69 | Personal

   Principal: Rs. 50,000.00 | Rate: 10.00% | Tenure: 12 months

   Monthly EMI: Rs. 4,395.79 | Total interest: Rs. 2,749.53



4. Shannu | LN-43198A254C | Vehicle

   Principal: Rs. 2,000,000.00 | Rate: 10.00% | Tenure: 16 months

   Monthly EMI: Rs. 134,037.81 | Total interest: Rs. 144,604.96

